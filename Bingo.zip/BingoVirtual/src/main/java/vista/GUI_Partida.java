/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;
import modelo.CartonBingo;
import modelo.Jugador;
import modelo.ValidarGanador;
import static vista.GUI_Juego.cartones;
import static vista.GUI_Juego.numerosJugados;
import static vista.GUI_Juego.setCartones;


/**
 *
 * @author dylan
 */
public final class GUI_Partida extends javax.swing.JFrame {
    private String premio;
    private String configuracion;
    public static List<Integer> numerosJugados;    
    public List<CartonBingo> ganadores;
    private int count; 
    
    /**
     * Creates new form GUI_Partida
     * @param pPremio
     * @param pConfiguracion
     */
    public GUI_Partida(String pPremio, String pConfiguracion) {
        initComponents();
        setLocationRelativeTo(null);
        
        setPremio(pPremio);
        setConfiguracion(pConfiguracion);
        numerosJugados = new ArrayList<Integer>();
        ganadores  = new ArrayList<CartonBingo>();
        count = 0;

        GUI_MENU_PRINCIPAL nuevoMenu = new GUI_MENU_PRINCIPAL();
        ArrayList<CartonBingo> cartones = nuevoMenu.getCartonesActuales();        
        List<Jugador> jugadores = nuevoMenu.getJugadores(); 
        
        jl_TipoJuego.setText("Tipo de Juego: " + getConfiguracion());
        jl_Premio.setText("Premio: " + getPremio() + " Colones");
        jl_TotalCartones.setText("Total de cartones: " + cartones.size());
        jl_TotalJugadores.setText("Total de jugadores: " + jugadores.size());

        btn_CantarNumero.addActionListener((ActionEvent e) -> {
            int numero = cantarNumero();
            String currentText = jl_NumeroCantados.getText();
            if (!currentText.isEmpty()) {
                currentText += ", ";
            }
            currentText += numero;
            
            // Agregar un cambio de línea cada 25 números
            if (currentText.split(",").length % 25 == 0) {
                currentText += "\n";
            }
            
            jl_NumeroCantados.setText(currentText);     
            if (currentText.split(",").length == 75) {
                JOptionPane.showMessageDialog(this, "No hay ganadores", "Error", JOptionPane.ERROR_MESSAGE);          
            }  
            juegoGeneral();
        });         
                       
    }
    
    // Métodos accesores
    public void setPremio(String pPremio) {
        premio = pPremio;
    }
    
    public String getPremio() {
        return premio;
    }
    
    public void setConfiguracion(String pConfiguracion) {
        configuracion = pConfiguracion;
    }

    public String getConfiguracion() {
        return configuracion;
    }

    public static void setCartones() {
        GUI_MENU_PRINCIPAL nuevoMenu = new GUI_MENU_PRINCIPAL();   
        GUI_Juego.cartones = nuevoMenu.getCartonesActuales();
    }

    public static void setNumerosJugados(List<Integer> numerosJugados) {
        GUI_Juego.numerosJugados = numerosJugados;
    }    
    
    public int cantarNumero() {
        Random random = new Random();
        int numero = 0;
        do {
          numero = 0;
          numero = random.nextInt(75 - 1 + 1) + 1;
        } while (numerosJugados.contains(numero) == true);
        numerosJugados.add(numero);                  
        return numero;
    }     

    public void juegoGeneral() {
        if (count == 0) {
            setCartones();
        }
        count++;

        ValidarGanador validador = new ValidarGanador();
        List<CartonBingo> ganadores = new ArrayList<CartonBingo>();
        boolean estado = false;
        String mode = getConfiguracion(); // Obtén el valor de configuración

        switch (mode) {
            case "Jugar en X":
                validador.verificarEnX(cartones, numerosJugados);
                ganadores = validador.ganadores;

                if (ganadores.size() != 0) {
                    estado = true;
                    String identificadores = "";
                    
                    for (CartonBingo uCarton : ganadores) {
                        identificadores += uCarton.getIdentificador() + " ";

                    }                                  
                    mostrarGanadores(identificadores);                    
                }
                break;

            case "Jugar en Z":
                validador.verificarEnZ(cartones, numerosJugados);
                ganadores = validador.ganadores;

                if (ganadores.size() != 0) {
                    estado = true;
                    String identificadores = "";
                    
                    for (CartonBingo uCarton : ganadores) {
                        identificadores += uCarton.getIdentificador() + ", ";

                    }                                  
                    mostrarGanadores(identificadores);                                    
                }
                break;

            case "Cuatro esquinas":
                validador.verificarCuatroEzquinas(cartones, numerosJugados);
                ganadores = validador.ganadores;

                if (ganadores.size() != 0) {
                    estado = true;
                    String identificadores = "";
                    
                    for (CartonBingo uCarton : ganadores) {
                        identificadores += uCarton.getIdentificador() + ", ";

                    }                                  
                    mostrarGanadores(identificadores);                    
                }
                break;

            case "Carton lleno":
                validador.verificarCartonLleno(cartones, numerosJugados);
                ganadores = validador.ganadores;

                if (ganadores.size() != 0) {
                    estado = true;
                    String identificadores = "";
                    
                    for (CartonBingo uCarton : ganadores) {
                        identificadores += uCarton.getIdentificador() + ", ";

                    }                                  
                    mostrarGanadores(identificadores);                    
                }
                break;
        }
        /*
        if (estado == true) {
          guardarDatosPartida();
        }
        */
    }
    
    private void mostrarGanadores(String identificadoresGanadores) {    
        
        GUI_Ganadores gui_Ganadores = new GUI_Ganadores(premio, configuracion, identificadoresGanadores);

        // Mostrar la ventana de partida
        gui_Ganadores.setVisible(true);

        // Ocultar esta ventana 
        this.setVisible(false);
    
    }    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jp_Encabezado = new javax.swing.JPanel();
        jl_TipoJuego = new javax.swing.JLabel();
        jl_Premio = new javax.swing.JLabel();
        jp_Cuerpo = new javax.swing.JPanel();
        jp_Contenido = new javax.swing.JPanel();
        btn_CantarNumero = new javax.swing.JButton();
        jp_NumeroCantados = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jl_NumeroCantados = new javax.swing.JTextArea();
        jl_SubTitulo = new javax.swing.JLabel();
        jl_TotalCartones = new javax.swing.JLabel();
        jl_TotalJugadores = new javax.swing.JLabel();

        jp_Encabezado.setBackground(new java.awt.Color(255, 255, 255));

        jl_TipoJuego.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jl_TipoJuego.setText("Tipo de Juego:");

        jl_Premio.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jl_Premio.setText("Premio:");

        javax.swing.GroupLayout jp_EncabezadoLayout = new javax.swing.GroupLayout(jp_Encabezado);
        jp_Encabezado.setLayout(jp_EncabezadoLayout);
        jp_EncabezadoLayout.setHorizontalGroup(
            jp_EncabezadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_EncabezadoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jp_EncabezadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jl_TipoJuego)
                    .addComponent(jl_Premio))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jp_EncabezadoLayout.setVerticalGroup(
            jp_EncabezadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_EncabezadoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jl_TipoJuego)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jl_Premio)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jp_Cuerpo.setBackground(new java.awt.Color(204, 204, 255));

        btn_CantarNumero.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btn_CantarNumero.setText("Cantar Número");

        jp_NumeroCantados.setBackground(new java.awt.Color(255, 255, 255));

        jl_NumeroCantados.setBackground(new java.awt.Color(255, 255, 255));
        jl_NumeroCantados.setColumns(20);
        jl_NumeroCantados.setRows(5);
        jl_NumeroCantados.setRequestFocusEnabled(false);
        jScrollPane2.setViewportView(jl_NumeroCantados);

        javax.swing.GroupLayout jp_NumeroCantadosLayout = new javax.swing.GroupLayout(jp_NumeroCantados);
        jp_NumeroCantados.setLayout(jp_NumeroCantadosLayout);
        jp_NumeroCantadosLayout.setHorizontalGroup(
            jp_NumeroCantadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
        jp_NumeroCantadosLayout.setVerticalGroup(
            jp_NumeroCantadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
        );

        jl_SubTitulo.setText("Números Cantados:");

        jl_TotalCartones.setText("Total de cartones:");

        jl_TotalJugadores.setText("Total de jugadores:");

        javax.swing.GroupLayout jp_ContenidoLayout = new javax.swing.GroupLayout(jp_Contenido);
        jp_Contenido.setLayout(jp_ContenidoLayout);
        jp_ContenidoLayout.setHorizontalGroup(
            jp_ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jp_ContenidoLayout.createSequentialGroup()
                .addContainerGap(223, Short.MAX_VALUE)
                .addComponent(btn_CantarNumero)
                .addGap(207, 207, 207))
            .addGroup(jp_ContenidoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jp_ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jp_ContenidoLayout.createSequentialGroup()
                        .addComponent(jp_NumeroCantados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jp_ContenidoLayout.createSequentialGroup()
                        .addComponent(jl_TotalCartones)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jl_TotalJugadores)
                        .addGap(29, 29, 29))
                    .addGroup(jp_ContenidoLayout.createSequentialGroup()
                        .addComponent(jl_SubTitulo)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jp_ContenidoLayout.setVerticalGroup(
            jp_ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_ContenidoLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(btn_CantarNumero)
                .addGap(8, 8, 8)
                .addComponent(jl_SubTitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jp_NumeroCantados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jp_ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jl_TotalCartones)
                    .addComponent(jl_TotalJugadores))
                .addContainerGap())
        );

        javax.swing.GroupLayout jp_CuerpoLayout = new javax.swing.GroupLayout(jp_Cuerpo);
        jp_Cuerpo.setLayout(jp_CuerpoLayout);
        jp_CuerpoLayout.setHorizontalGroup(
            jp_CuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_CuerpoLayout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addComponent(jp_Contenido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jp_CuerpoLayout.setVerticalGroup(
            jp_CuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_CuerpoLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jp_Contenido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jp_Encabezado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jp_Cuerpo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jp_Encabezado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jp_Cuerpo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_Partida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_Partida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_Partida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_Partida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {             
                new GUI_Partida("","").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_CantarNumero;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jl_NumeroCantados;
    private javax.swing.JLabel jl_Premio;
    private javax.swing.JLabel jl_SubTitulo;
    private javax.swing.JLabel jl_TipoJuego;
    private javax.swing.JLabel jl_TotalCartones;
    private javax.swing.JLabel jl_TotalJugadores;
    private javax.swing.JPanel jp_Contenido;
    private javax.swing.JPanel jp_Cuerpo;
    private javax.swing.JPanel jp_Encabezado;
    private javax.swing.JPanel jp_NumeroCantados;
    // End of variables declaration//GEN-END:variables
}
